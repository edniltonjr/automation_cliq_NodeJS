const puppeteer = require('puppeteer');
const { promisify } = require('util')
const express = require('express')
const app = express();
require('dotenv').config()



app.get('/enviarENG', (req, res) => {

    const {eng} = req.query;

    const sleep = promisify(setTimeout);



(async () => {
  const browser = await puppeteer.launch({
       executablePath: process.env.executablePath,
        userDataDir: process.env.userDataDir,
        headless: process.env.headless === 'false' ? false : true
  });



  const page = await browser.newPage();
  await page.goto('https://accounts.zoho.com/signin?servicename=ZohoChat&serviceurl=/index.do');
  await page.screenshot({ path: 'example.png' });

  await sleep(1000 * 2);

const [span] = await page.$x("//span[contains(text(), 'Rodrigo')]");

console.log(span)
if (span) {
    await span.click();

      await sleep(1000 * 1);


    await page.waitForTimeout('div[id="tab2243210302256597694]');

    await page.$eval('div[id="composer2243210302256597694"]', (el, value) => el.innerHTML = value, `${eng} - preparada para deploy`);

    await page.click('div[id="composer2243210302256597694"]');

    await page.keyboard.press('Enter');

}

process.env.headless === 'true' ? await browser.close() : await sleep(1000 * 300);

await res.json('ENG enviada com Sucesso')

})();

})


app.listen(3339);



